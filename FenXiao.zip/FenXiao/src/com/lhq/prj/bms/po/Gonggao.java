package com.lhq.prj.bms.po;

public class Gonggao {

}
